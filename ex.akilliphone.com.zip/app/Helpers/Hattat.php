<?php
class Hattat{
    public static function auth_logout(){

    }
}
