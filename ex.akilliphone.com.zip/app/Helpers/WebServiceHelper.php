<?php
if(is_file( dirname(__FILE__).'/Hattat.php') ){
    include_once( dirname(__FILE__).'/Hattat.php' );
}
if(is_file( dirname(__FILE__).'/WebServiceFilter.php') ){
    include_once( dirname(__FILE__).'/WebServiceFilter.php' );
}
if(is_file( dirname(__FILE__).'/WebService.php') ){
    include_once( dirname(__FILE__).'/WebService.php' );
}
if(is_file( dirname(__FILE__).'/CommonHelper.php') ){
    include_once( dirname(__FILE__).'/CommonHelper.php' );
}
if(is_file( dirname(__FILE__).'/PaymentService.php') ){
    include_once( dirname(__FILE__).'/PaymentService.php' );
}
if(is_file( dirname(__FILE__).'/BasketService.php') ){
    include_once( dirname(__FILE__).'/BasketService.php' );
}
if(is_file( dirname(__FILE__).'/OrderService.php') ){
    include_once( dirname(__FILE__).'/OrderService.php' );
}
if(is_file( dirname(__FILE__).'/MailService.php') ){
    include_once( dirname(__FILE__).'/MailService.php' );
}


