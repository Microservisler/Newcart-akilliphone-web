<section class="banner-area section-padding">
    <div class="container">
        <a href="#">
            <img class="lazyload fluid-img" data-src="{{ url('assets/images/banners/desktop-banner1.png') }}"
                 data-srcset="{{ url('assets/images/banners/desktop-banner1.png') }} 800w, {{ url('assets/images/banners/mobile-banner1.png') }} 320w"
                 sizes="(min-width: 768px) 400px,160px" width="1110" height="120" alt="Banner">
        </a>
    </div>
</section>
