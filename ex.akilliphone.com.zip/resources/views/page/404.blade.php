@extends('layouts.default')
@section('head')
    <title>Sayfa Bulunamadı - AkilliPhone</title>
    <link rel="stylesheet" href="{{ url('assets/css/contact-us.css') }}">
@endsection
@section('content')
    <section class="contact-us mx-24">
        <div class="container">
            <div class="contact-us-title">
                <h1>Sayfa Bulunamadı</h1>
            </div>
            <div class="row">
                <div class="col-12 col-lg-6"></div>
                <div class="col-12 col-lg-6"></div>
            </div>
        </div>
    </section>
@endsection
