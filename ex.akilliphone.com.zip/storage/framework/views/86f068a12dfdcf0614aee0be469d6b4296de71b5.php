<?php
$index = isset($index)?(int)$index:0;
if($items){
foreach($items as $item){
    if($item['orderNumber']!=$index) continue; ?>
<section class="banner-area section-padding">
    <div class="container">
        <a href="#">
            <img class="lazyload fluid-img" data-src="<?php echo e($item['desktopImage']); ?>"
                 data-srcset="<?php echo e($item['desktopImage']); ?> 800w, <?php echo e($item['mobileImage']); ?> 320w"
                 sizes="(min-width: 768px) 400px,160px" width="1110" height="120" alt="Banner">
        </a>
    </div>
</section>
<?php }
}?>
<?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/components/section/tall-banner.blade.php ENDPATH**/ ?>