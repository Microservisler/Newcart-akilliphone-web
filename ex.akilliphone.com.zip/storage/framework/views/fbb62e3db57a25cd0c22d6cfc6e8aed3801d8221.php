
<?php $__env->startSection('head'); ?>
    <title>Siparişler - AkıllıPhone</title>
    <link rel="stylesheet" href="<?php echo e(url('assets/css/profile/order/main.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <section class="profile section-padding mx-24">
        <div class="container">
            <div class="section-title">Hesabım</div>
            <div class="profile-layout">
                <div class="left">
                    <div class="user-info">
                        <div class="shortened">EK</div>
                        <div class="fullname">Emre Karataş</div>
                    </div>
                    <div>
                        <a href="../siparislerim/index.html" class="left-section active">
                            <div class="left-section-title">
                                <img src="assets/images/icons/order.svg" alt="">
                                Siparişlerim
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="../coupons/index.html" class="left-section">
                            <div class="left-section-title">
                                <img src="assets/images/icons/coupon.svg" alt="">
                                Kuponlarım
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="../favorites/index.html" class="left-section">
                            <div class="left-section-title">
                                <img src="assets/images/icons/favorite.svg" alt="">
                                Favorilerim / Listelerim
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="../comments/index.html" class="left-section">
                            <div class="left-section-title">
                                <img src="assets/images/icons/comment.svg" alt="">
                                Yorumlarım
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="../üyelikbilgileri/index.html" class="left-section">
                            <div class="left-section-title">
                                <img src="assets/images/icons/info.svg" alt="">
                                Üyelik Bilgilerim
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="../address/index.html" class="left-section">
                            <div class="left-section-title">
                                <img src="assets/images/icons/address.svg" alt="">
                                Adres Bilgilerim
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                    </div>
                </div>
                <div class="right">
                    <div class="orders">
                        <div class="top">
                            <div class="title">Siparişlerim</div>
                            <div class="search">
                                <input placeholder="Ürün İsmi veya Marka Ara" type="search">
                                <button class=""><img width="49" height="49" src="assets/images/search-icon.svg"
                                                      alt="">
                                </button>
                            </div>
                            <div class="signup-select">
                                <select>
                                    <option value="0"></option>
                                    <option value="1" selected>Tüm siparişler</option>
                                    <option value="2">Son 30 Gün</option>
                                    <option value="3">Son 6 Ay</option>
                                </select>
                            </div>
                        </div>
                        <div class="order-list">
                            <div class="order">
                                <div class="order-header">
                                    <div class="info">
                                        <div class="title">Sipariş Tarihi</div>
                                        <div class="descr">29 Ekim 2022 - 18:51</div>
                                    </div>
                                    <div class="info">
                                        <div class="title">Sipariş Özeti</div>
                                        <div class="descr">1 Teslimat, 2 Ürün</div>
                                    </div>
                                    <div class="info">
                                        <div class="title">Alıcı</div>
                                        <div class="descr">Emre Karataş</div>
                                    </div>
                                    <div class="info">
                                        <div class="title">Tutar</div>
                                        <div class="descr">118,90 TL</div>
                                    </div>
                                    <a class="refund-btn" href="#">İade Talebi</a>
                                </div>
                                <div class="order-body">
                                    <div class="product-details">
                                        <div class="product-img">
                                            <img src="assets/images/product2.png" alt="product name">
                                        </div>
                                        <div class="product-info">
                                            <div class="name">
                                                ALLY Magnetic Air Vent
                                                Mıknatıslı Araç Tutucu Kablo Klipsli-SİYAH
                                            </div>
                                            <div class="code">
                                                HBV000009KUEB
                                            </div>
                                        </div>
                                    </div>
                                    <a class="order-detail" href="./detail.html">Sipariş Detayı</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="../assets/js/profile/order/profile-order.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/profile/order/profile.blade.php ENDPATH**/ ?>