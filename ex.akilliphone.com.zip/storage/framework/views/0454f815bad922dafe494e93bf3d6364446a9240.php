<section class="section-padding mx-24" style="overflow:hidden;">
    <div class="home-slider owl-carousel owl-theme">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $bgColor = $item['bgColor']?$item['bgColor']:'#FFFFFF';
?>
                <div class="slider-wrapper slider-back-<?php echo e($i); ?>" style="background-color: <?php echo e($bgColor); ?>"  data-dot="<img src='<?php echo e($item['thumb']); ?>'/>">
                    <div class="container">
                        <div class="content">
                            <div class="product-name"><?php echo e($item['title']); ?></div>
                            <a class="product-link" href="<?php echo e($item['slug']); ?>">Acele et kaçırma</a>
                            <span class="share-btn">
                            <img width="17" height="22" src="assets/images/svg/share-btn.svg" alt="">
                            <ul class="share-links">
                                <li>
                                    <a href="#" class="share-link">
                                        <div class="icon"></div>
                                        <div class="name">Whatsapp'dan paylaş</div>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="share-link">
                                        <div class="icon"></div>
                                        <div class="name">Facebook'ta paylaş</div>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="share-link">
                                        <div class="icon"></div>
                                        <div class="name">Twitter'da paylaş</div>
                                    </a>
                                </li>
                            </ul>
                        </span>
                        </div>
                        <div class="product-img">
                            <img class="fluid-img" width="1110" height="390" src="<?php echo e($item['desktopImage']); ?>"
                                 srcset="<?php echo e($item['desktopImage']); ?> 800w, <?php echo e($item['mobileImage']); ?> 320w"
                                 sizes="(min-width: 768px) 400px,160px" alt="">
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/components/section/main-slider.blade.php ENDPATH**/ ?>