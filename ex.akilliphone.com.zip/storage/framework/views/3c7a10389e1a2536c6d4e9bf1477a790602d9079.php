<?php
if($items){?>
<div class="three-category-block">
    <?php foreach($items as $item){?>

        <img class="lazyload fluid-img" data-srcset="<?php echo e($item['desktopImage']); ?> 1x, <?php echo e($item['desktopImage']); ?> 2x" data-src="<?php echo e($item['mobileImage']); ?>" >

    <?php }?>
</div>
<?php } ?>
<?php /**PATH /home/akilliphone/subdomains/ex.akilliphone.com/resources/views/components/section/three-banner.blade.php ENDPATH**/ ?>