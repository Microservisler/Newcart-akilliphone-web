<?php $__env->startSection('head'); ?>
    <title>Üyelik Bilgilerim - AkıllıPhone</title>
    <link rel="stylesheet" href="<?php echo e(url('assets/css/profile/informations/main.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php $user=session('userInfo'); ?>
    <section class="profile section-padding mx-24">
        <div class="container">
            <div class="section-title">Hesabım</div>
            <div class="profile-layout">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.profile.left-sidebar','data' => []]); ?>
<?php $component->withName('profile.left-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <div class="right">
                    <div class="profile-infos">
                        <div class="top">
                            <div class="title">Üyelik Bilgilerim</div>
                        </div>
                        <form action="<?php echo e(route('profile.userUpdate')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-wrapper">
                                <div class="signup-input">
                                    <span class="label">Adı<span>&nbsp;*</span></span>
                                    <input type="text" name="firstName" value="<?php echo $user['data']['firstName']; ?>">
                                </div>
                                <div class="signup-input">
                                    <span class="label">Soyadı<span>&nbsp;*</span></span>
                                    <input type="text" name="lastName" value="<?php echo $user['data']['lastName']; ?>">
                                </div>

                                <div class="signup-input">
                                    <span class="label">E-Posta Adresi<span>&nbsp;*</span></span>
                                    <input type="text" name="email" value="<?php echo $user['data']['email']; ?>">
                                </div>
                                <div class="signup-input">
                                    <span class="label">Kullanıcı Adı<span>&nbsp;*</span></span>
                                    <input type="text" name="username" value="<?php echo $user['data']['userName']; ?>">
                                </div>
                                <div class="signup-input">
                                    <span class="label">Cep Tel<span>&nbsp;*</span></span>
                                    <input id="mobilePhone" type="text" name="phoneNumber" value="<?php echo $user['data']['phoneNumber']; ?>">
                                </div>

                                <div class="signup-input">
                                    <span class="label">Doğum Tarihi<span>&nbsp;*</span></span>
                                    <input type="text" id="date-picker" name="birthDate" value="<?php echo $user['data']['birthDate']; ?>">
                                </div>
                                <div class="signup-input">
                                    <span class="label">Tc Kimlik No<span>&nbsp;*</span></span>
                                    <input id="mobilePhone" type="text" name="tcKimlik" value="<?php echo $user['data']['tcKimlik']; ?>">
                                </div>
                                <div class="signup-agreement">
                                    <label for="membership">
                                        <input class="option-input checkbox" type="checkbox" id="membership"
                                               required>
                                        Üyelik Sözleşmesi şartlarını okudum ve kabul ediyorum. Tarafımla pazarlama
                                        ve tanıtım amaçlı iletişime geçilmesine izin veriyorum.
                                    </label>
                                </div>
                                <div class="signup-buttons">
                                    <button type="submit" class="submit-btn" >Bilgilerimi Güncelle</button>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="../assets/js/profile/order/profile-order.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/profile/informations.blade.php ENDPATH**/ ?>