<section class="section-9 section-padding mx-24">
    <div class="container">
        <div class="section-title section-padding px-24">
            Favori Markaların
            <a class="link" href="#">Tümünü Gör</a>
        </div>

        <div class="left-slider">
            <div class="one-card-slider owl-carousel owl-theme">
<?php $__currentLoopData = $products['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <div class="card-slider">
                    <div class="card-brand"><img class="lazyload" width="100" height="30"
                                                 data-src="<?php echo getProductImageUrl($productItem['brandImage']); ?>" alt="<?php echo e($productItem['brandName']); ?>"></div>
                    <hr class="divider">
                    <div class="card-image"><img class="lazyload" width="128" height="128"
                                                 data-src="<?php echo getProductImageUrl($productItem['image']); ?>" alt="Xiaomi"></div>
                    <div class="card-info">
                        <div class="card-name"><?php echo e($productItem['name']); ?></div>
                        <div class="card-prices">
                            <div class="card-price">
                                <span class="current"><?php echo e(number_format($productItem['newPrice'], 2, '.', '')); ?> TL</span>
                                <span class="discount">%27</span>
                            </div>
                            <div class="card-old-price"><?php echo e(number_format($productItem['oldPrice'], 2, '.', '')); ?> TL </div>
                        </div>
                        <div class="add-btn"><a href="#">Sepete Ekle</a></div>
                    </div>
                    <a class="all-brands" href="#">Tüm <?php echo e($productItem['brandName']); ?> Ürünleri</a>
                </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
        <div class="favorite-brands">
            <div class="section-title section-padding">
                Favori Markaların
                <a class="link" href="/reyonlar">Tüm Markalar</a>
            </div>
            <div class="brand-slider swiper">
                <div class="swiper-wrapper">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide">
                    <a href="<?php echo e(url("reyonlar?brand=".$item['brandId'])); ?>" class="brand-logo"><img class="lazyload fluid-img" data-src="<?php echo getProductImageUrl($item['image']); ?>" alt="<?php echo e($item['name']); ?>"></a>
                        </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/components/section/brands.blade.php ENDPATH**/ ?>