<?php $__env->startSection('head'); ?>
    <title>Yorumlarım - AkıllıPhone</title>
    <link rel="stylesheet" href="<?php echo e(url('assets/css/profile/comments/main.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <section class="profile section-padding mx-24">
        <div class="container">
            <div class="section-title">Hesabım</div>
            <div class="profile-layout">
                <div class="left">
                    <div class="user-info">
                        <div class="shortened"><?php echo session('userNameIcon'); ?></div>
                        <div class="fullname">Ethem Kurt</div>
                    </div>
                    <div>
                        <a href="order" class="left-section ">
                            <div class="left-section-title">
                                <img src="../assets/images/icons/order.svg" alt="">
                                Siparişlerim
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="coupons" class="left-section">
                            <div class="left-section-title">
                                <img src="../assets/images/icons/coupon.svg" alt="">
                                Kuponlarım
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="favorites" class="left-section">
                            <div class="left-section-title">
                                <img src="../assets/images/icons/favorite.svg" alt="">
                                Favorilerim / Listelerim
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="comments" class="left-section active">
                            <div class="left-section-title">
                                <img src="../assets/images/icons/comment.svg" alt="">
                                Yorumlarım
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="informations" class="left-section">
                            <div class="left-section-title">
                                <img src="../assets/images/icons/info.svg" alt="">
                                Üyelik Bilgilerim
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="address" class="left-section">
                            <div class="left-section-title">
                                <img src="../assets/images/icons/address.svg" alt="">
                                Adres Bilgilerim
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="payment"  class="left-section">
                            <div class="left-section-title">
                                <img src="../assets/images/icons/card.svg" alt="">
                                Harici Ödeme
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847"
                                 viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527"
                                      d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z"
                                      transform="translate(11.054 10.947) rotate(180)" opacity="0.492" />
                            </svg>
                        </a>
                    </div>
                </div>
                <div class="right">
                    <div class="profile-infos">
                        <div class="top">
                            <div class="title">Yorumlarım</div>
                            <div>3 Yorum</div>
                        </div>
                        <div class="comment-list">
                            <div class="comment">
                                <div class="comment-header">
                                    <div class="comment-header-top">
                                        <img src="../assets/images/product1.png" width="80" height="80" alt="">
                                        <div>Hoco iPhone 14 Plus 6.7 Kılıf Manyetik Magsafeli Darbe Emici Telefon Kılıfı</div>
                                    </div>
                                    <div class="comment-header-bottom">
                                        <div class="rating-area">
                                            <span><img src="../assets/images/full-star.svg" alt=""></span>
                                            <span><img src="../assets/images/full-star.svg" alt=""></span>
                                            <span><img src="../assets/images/full-star.svg" alt=""></span>
                                            <span><img src="../assets/images/full-star.svg" alt=""></span>
                                            <span><img src="../assets/images/empty-star.svg" alt=""></span>
                                        </div>
                                        <div>18 Şubat Cumartesi </div>
                                    </div>
                                </div>
                                <div class="comment-body">
                                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quisquam suscipit dolorem assumenda itaque! Voluptatum repellendus a neque, nihil delectus vitae!
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="../assets/js/profile/order/profile-order.js"></script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/components/profile/comments.blade.php ENDPATH**/ ?>