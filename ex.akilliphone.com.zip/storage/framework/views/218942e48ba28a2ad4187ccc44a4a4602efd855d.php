<section class="section-padding <?php echo e($class); ?>">
    <div class="container">
        <div class="section-title section-padding">
            <?php echo e($title); ?>

            <a class="link" href="<?php echo getUrlBySlug($slug); ?>">Tümünü Gör</a>
        </div>
        <div class="row">
            <?php if($banner): ?>
                <div class="side-campaign">
                    <a href="#">
                        <img class="lazyload fluid-img" width="160" height="600"
                             data-src="<?php echo e($banner); ?>" alt="Baseus Fırsatı Kaçırma">
                    </a>
                </div>

            <?php endif; ?>
            <div class="product-items">
                <div class="row">
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if (isset($component)) { $__componentOriginalb8fb63116f7457724379367482532fd81815847a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Product\HomeItem::class, ['item' => $item]); ?>
<?php $component->withName('product.home-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb8fb63116f7457724379367482532fd81815847a)): ?>
<?php $component = $__componentOriginalb8fb63116f7457724379367482532fd81815847a; ?>
<?php unset($__componentOriginalb8fb63116f7457724379367482532fd81815847a); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/components/section/grid.blade.php ENDPATH**/ ?>