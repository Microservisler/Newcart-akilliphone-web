<section class="recently-viewed section-padding">
    <div class="container">
        <div class="section-title section-padding">
            Son İnceledikleriniz
        </div>
        <div class="product-slider owl-carousel owl-theme">
            <?php if(\Akilliphone\BasketService::getLastVieweds()): ?>
                <?php $__currentLoopData = \Akilliphone\BasketService::getLastVieweds(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginal5ef3a6e9f6ca3594183882eb43fa756b943550ad = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Product\HomeItem2::class, ['item' => $item]); ?>
<?php $component->withName('product.home-item2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ef3a6e9f6ca3594183882eb43fa756b943550ad)): ?>
<?php $component = $__componentOriginal5ef3a6e9f6ca3594183882eb43fa756b943550ad; ?>
<?php unset($__componentOriginal5ef3a6e9f6ca3594183882eb43fa756b943550ad); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/components/product/recently-viewed.blade.php ENDPATH**/ ?>