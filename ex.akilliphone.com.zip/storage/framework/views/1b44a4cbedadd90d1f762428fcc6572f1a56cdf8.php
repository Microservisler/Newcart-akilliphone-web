<div class="cart-wrapper">
    <div class="header">
        <div class="title">Sepetim</div>
        <span class="item-count"><?php echo e($basket->basketItemCount); ?></span>
    </div>
    <!--<div class="body">
                <?php $__currentLoopData = $basket->basketItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="purchased">
            <img src="<?php echo e($item['featuredImage']); ?>" alt="">
                    <div class="info">
                        <div class="name"><?php echo e($item['productName']); ?><br><?php echo e($item['name']); ?></div>
                        <div class="price"><?php echo e($item['total']); ?><span>&nbsp;TL</span></div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>-->
    <div class="total">
        <?php if($basket->basketSubtotals): ?>
            <?php $__currentLoopData = $basket->basketSubtotals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basketSubtotal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($basketSubtotal): ?>
                    <div class="info-total">
                        <div class="descr"><?php echo e($basketSubtotal['title']); ?></div>
                        <div class="price"><?php echo e($basketSubtotal['total']); ?><span>&nbsp;TL</span></div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
    <div class="basket-messages">
        <?php $__currentLoopData = $basket->alerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="basket-message <?php echo e($alert['class']); ?>"><?php echo e($alert['message']); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($basket->shippingBrand && isset($basket->shippingBrands[$basket->shippingBrand])): ?>
                <div class="basket-message info"><?php echo e($basket->shippingBrands[$basket->shippingBrand]['title']); ?> İle Gönderilecek</div>
            <?php endif; ?>
    </div>
    <div class="total-footer">
        <div class="info-total">
            <div class="descr">Toplam</div>
            <div class="price"><?php echo e($basket->total); ?><span>&nbsp;TL</span></div>
        </div>
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
        <button class="payment-next" type="submit"><?php echo e($buttonText); ?></button>
    </div>
</div>
<?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/components/payment/cart-wrapper.blade.php ENDPATH**/ ?>