<?php $__env->startSection('head'); ?>
    <title><?php echo e($page); ?> - AkıllıPhone</title>
    <link rel="stylesheet" href='<?php echo e(url("assets/css/profile/".$page."/main.css")); ?>'>
    <link rel="stylesheet" href="<?php echo e(url('assets/css/profile/informations/main.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="profile section-padding mx-24">
        <div class="container">
            <div class="section-title">Hesabım</div>
            <div class="profile-layout">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.profile.left-sidebar','data' => []]); ?>
<?php $component->withName('profile.left-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <div class="right">
                    <div class="profile-infos">
                        <div class="top">
                            <div class="title">Üyelik Bilgilerim</div>
                        </div>
                        <form action="">
                            <div class="form-wrapper">
                                <div class="signup-input">
                                    <span class="label">Adı<span>&nbsp;*</span></span>
                                    <input type="text">
                                </div>
                                <div class="signup-input">
                                    <span class="label">Soyadı<span>&nbsp;*</span></span>
                                    <input type="text">
                                </div>
                                <div class="signup-input">
                                    <span class="label">E-Posta Adresi<span>&nbsp;*</span></span>
                                    <input type="text">
                                </div>
                                <div class="signup-input">
                                    <div class="signup-select">
                                        <span class="label">Cinsiyet<span>&nbsp;*</span></span>
                                        <select>
                                            <option value="0"></option>
                                            <option value="1">Erkek</option>
                                            <option value="2">Kadın</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="signup-input">
                                    <span class="label">Doğum Tarihi<span>&nbsp;*</span></span>
                                    <input type="text" id="date-picker">
                                </div>
                                <div class="signup-input">
                                    <span class="label">Cep Tel<span>&nbsp;*</span></span>
                                    <input id="mobilePhone" type="text">
                                </div>
                                <div class="signup-agreement">
                                    <label for="membership">
                                        <input class="option-input checkbox" type="checkbox" id="membership"
                                               required>
                                        Üyelik Sözleşmesi şartlarını okudum ve kabul ediyorum. Tarafımla pazarlama
                                        ve tanıtım amaçlı iletişime geçilmesine izin veriyorum.
                                    </label>
                                </div>
                                <div class="signup-buttons">
                                    <a class="submit-btn" href="#">Bilgilerimi Güncelle</a>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="../assets/js/profile/order/profile-order.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/profile/index.blade.php ENDPATH**/ ?>