<?php $__env->startSection('head'); ?>
    <title>İşlem Rehberi - AkıllıPhone</title>
    <link rel="stylesheet" href="<?php echo e(url('assets/css/aboutUs.css?_t=1.01')); ?>">
    <style>
        .welcome-about {
            margin: 0px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="welcome-about">
        <h1 class="main-title">İşlem Rehberi</h1>
     <br>
        <div class="aboutus-content">

            Teknik Adımlar:
            <br>
            <ul>
                <li>
                    Mal ve Hizmetin Seçilmesi: İlgilendiğiniz ürün veya hizmeti seçin ve sepete ekleyin.
                </li>
                <li>Teslimat Bilgilerinin Girilmesi: Teslimat adresinizi ve iletişim bilgilerinizi girin.
                </li>
                <li> Ödeme Bilgilerinin Girilmesi: Ödeme yönteminizi seçin ve gerekli bilgileri girin.

                </li>
                <li>  Siparişin Onaylanması: Sipariş özetini kontrol edin ve onaylayın.

                </li>

            </ul><br>


            <h2 style="font-weight: bold;font-size: 20px;padding: 20px">Sözleşme Erişimi ve Saklama
            </h2>
            Elektronik ticarete ilişkin sözleşme, elektronik ortamda saklanır. Alıcı, sözleşmeye aynı ortamda 30 gün süreyle erişebilir.

            <h2 style="font-weight: bold;font-size: 20px;padding: 20px">Veri Girişi ve Düzeltme
            </h2>
            Alıcılar, sipariş vermeden önce veri girişindeki hataları "Özet Sipariş Formu" aracılığıyla açık ve anlaşılır bir şekilde belirleyebilir ve "Geri Al ve Değiştir" gibi teknik araçlar kullanarak düzeltebilirler.


            <h2 style="font-weight: bold;font-size: 20px;padding: 20px">Gizlilik Kuralları</h2>

            Elektronik ticaret işlemleri nedeniyle elde ettiğimiz kişisel verilere ilişkin gizlilik kuralları, web sitemizin Gizlilik Politikası bölümünde detaylı olarak açıklanmıştır.
            <br>


            <h2 style="font-weight: bold;font-size: 20px;padding: 20px">Alternatif Uyuşmazlık Çözüm Mekanizmaları
            </h2>
            Alıcıyla arasında uyuşmazlık çıkması halinde, mesafeli satış sözleşmesinin, “Uyuşmazlıkların Çözümü” bölümünde belirtilen mekanizmalar kullanılabilir.
            <br>


        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/page/islem-rehberi.blade.php ENDPATH**/ ?>