<div class="totals">
    <div class="totals-header">
        <span>Sipariş Özeti</span>
        <span><?php echo e($basket->basketItemCount); ?> ürün</span>
    </div>
    <div class="totals-item totals-item-total">
        <label>Ödenecek Tutar</label>
        <div class="totals-value"><?php echo e($basket->total); ?></div>
    </div>
    <a href="<?php echo e(route('payment')); ?>" class="checkout">Alışverişi Tamamla
        <svg xmlns="http://www.w3.org/2000/svg" width="6.242" height="10.95" viewBox="0 0 6.242 10.95">
            <g id="flaticon1568189262-svg" transform="translate(-97.139 0)">
                <path id="Path_1398" data-name="Path 1398" d="M103.156,6.017l-4.708,4.708a.767.767,0,0,1-1.084-1.084l4.166-4.166L97.363,1.309A.767.767,0,0,1,98.448.224l4.708,4.708a.767.767,0,0,1,0,1.084Z" fill="#fff"></path>
            </g>
        </svg>
    </a>
    <?php if($basket->basketSubtotals): ?>
        <?php $__currentLoopData = $basket->basketSubtotals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $basketSubtotal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($basketSubtotal): ?>
                <div class="totals-item">
                    <label><?php echo e($basketSubtotal['title']); ?></label>
                    <div class="totals-value" id="cart-subtotal"><?php echo e($basketSubtotal['total']); ?>&nbsp;</div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    
    
    
    
    
    
    
    
    
    
    
    
    
    <div class="basket-messages">
        <?php $__currentLoopData = $basket->alerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="basket-message <?php echo e($alert['class']); ?>"><?php echo e($alert['message']); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH /home/akilliphone/subdomains/ex.akilliphone.com/resources/views/basket/totals.blade.php ENDPATH**/ ?>