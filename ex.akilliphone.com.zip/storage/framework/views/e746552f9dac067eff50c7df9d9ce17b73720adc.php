<?php $__env->startSection('head'); ?>
    <title>Sayfa Bulunamadı - AkilliPhone</title>
    <link rel="stylesheet" href="<?php echo e(url('assets/css/contact-us.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="contact-us mx-24">
        <div class="container">
            <div class="contact-us-title">
                <h1>Sayfa Bulunamadı</h1>
            </div>
            <div class="row">
                <div class="col-12 col-lg-6"></div>
                <div class="col-12 col-lg-6"></div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/page/404.blade.php ENDPATH**/ ?>