<div class="product-item">
    <a href="<?php echo e(url('incele')); ?>/<?php echo e($item['slug']); ?>?id=<?php echo e($item['productId']); ?>">
        <div class="product-image">

            <img class="lazyload" style="height:160px;width: 160px;" data-src="" alt="product image" src="<?php echo getProductImageUrl($item['featuredImage']) ?>">
        </div>
        <div class="product-info">
            <div class="product-name"><?php echo e($item['name']); ?></div>
            <div class="product-price">
                <span> <?php echo e(number_format($item['variants'][0]['price'], 2, '.', '')); ?> TL</span>
                <?php if(number_format($item['discountRate'], 0, '.', '')>0): ?>
                    <span class="discount"> %<?php echo e(number_format($item['discountRate'], 0, '.', '')); ?>  </span>

                <?php endif; ?>


            </div>
            <?php if($item['variants'][0]['price'] > $item['variants'][0]['oldPrice']): ?>
                <div class="product-old-price" ><?php echo e(number_format($item['variants'][0]['oldPrice'], 2, '.', '')); ?> TL</div>
            <?php endif; ?>
        </div>
    </a>
</div>
<?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/components/product/home-item2.blade.php ENDPATH**/ ?>