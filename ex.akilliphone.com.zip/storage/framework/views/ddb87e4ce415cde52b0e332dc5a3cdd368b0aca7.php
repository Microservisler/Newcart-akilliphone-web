
<?php $__env->startSection('head'); ?>
    <title>Harici Ödeme Sayfası - AkıllıPhone</title>
    <link rel="stylesheet" href="<?php echo e(url('assets/css/profile/payment/main.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <section class="profile section-padding mx-24">
        <div class="container">
            <div class="section-title">Hesabım</div>
            <div class="profile-layout">
                <div class="left">
                    <div class="user-info">
                        <div class="shortened"><?php echo session('userNameIcon'); ?></div>
                        <div class="fullname"><?php echo session('userName'); ?></div>
                    </div>
                    <div>
                        <a href="order" class="left-section ">
                            <div class="left-section-title">
                                <img src="../assets/images/icons/order.svg" alt="">
                                Siparişlerim
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="coupons" class="left-section">
                            <div class="left-section-title">
                                <img src="../assets/images/icons/coupon.svg" alt="">
                                Kuponlarım
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="favorites" class="left-section">
                            <div class="left-section-title">
                                <img src="../assets/images/icons/favorite.svg" alt="">
                                Favorilerim / Listelerim
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="comments" class="left-section ">
                            <div class="left-section-title">
                                <img src="../assets/images/icons/comment.svg" alt="">
                                Yorumlarım
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="informations" class="left-section">
                            <div class="left-section-title">
                                <img src="../assets/images/icons/info.svg" alt="">
                                Üyelik Bilgilerim
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="address" class="left-section">
                            <div class="left-section-title">
                                <img src="../assets/images/icons/address.svg" alt="">
                                Adres Bilgilerim
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="payment"  class="left-section" active>
                            <div class="left-section-title">
                                <img src="../assets/images/icons/card.svg" alt="">
                                Harici Ödeme
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847"
                                 viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527"
                                      d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z"
                                      transform="translate(11.054 10.947) rotate(180)" opacity="0.492" />
                            </svg>
                        </a>
                    </div>
                </div>
                <div class="right">
                    <div class="profile-infos">
                        <div class="top">
                            <div class="title">Harici Ödeme</div>
                        </div>
                        <form action="">
                            <div class="form-wrapper">
                                <div class="signup-input">
                                    <span class="label">Tutar Girişi<span>&nbsp;*</span></span>
                                    <input id="price" type="text" required>
                                </div>
                                <div class="signup-input">
                                    <span class="label">Ad Soyad<span>&nbsp;*</span></span>
                                    <input type="text" required>
                                </div>
                                <div class="signup-input">
                                    <span class="label">Cep Tel<span>&nbsp;*</span></span>
                                    <input id="mobilePhone" type="text" required>
                                </div>
                                <div class="signup-input">
                                    <span class="label">Kart No<span>&nbsp;*</span></span>
                                    <input id="creditCard" type="text" required>
                                </div>
                                <div class="signup-input">
                                    <span for="" class="label">Tarih<span>&nbsp;*</span></span>
                                    <input id="expiry" type="text" required>
                                </div>
                                <div class="signup-input">
                                    <span for="" class="label">CVV<span>&nbsp;*</span></span>
                                    <input id="cvv" type="text" required>
                                </div>
                                <div class="signup-input">
                                    <span class="label">E-Posta Adresi<span>&nbsp;*</span></span>
                                    <input type="email" required>
                                </div>
                                <div class="signup-input">
                                    <span class="label">Açıklama</span>
                                    <input type="text">
                                </div>
                                <div class="signup-buttons">
                                    <a id="completePayment" class="submit-btn" href="#">Ödemeyi Tamamla</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/lazyload@2.0.0-rc.2/lazyload.js"></script>
    <script src="assets/js/app.js"></script>
    <script src="./assets/js/mask.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Elemanlar
        var mobilePhone = document.getElementById('mobilePhone');
        var creditCard = document.getElementById('creditCard');
        var expiryInput = document.getElementById('expiry');
        var cvvInput = document.getElementById('cvv');
        var payBtn = document.getElementById('completePayment');
        var priceInput = document.getElementById('price');


        // Son kullanma tarihi maskeleme
        var expiryMask = IMask(expiryInput, {
            mask: '00/00'
        });

        // CVV maskeleme
        var cvvMask = IMask(cvvInput, {
            mask: /^[0-9]\d{0,3}$/
        });

        // Telefon maskeleme
        var phoneMask = IMask(mobilePhone, {
            mask: '+{9\\0} (000) 000 00 00',
            lazy: true,
        });

        // Kart numarası maskeleme
        var cardMask = IMask(creditCard, {
            mask: '0000 0000 0000 0000',
            lazy: true,
        });

        // Para miktarı maskeleme
        var paraMask = IMask(priceInput, {
            mask: Number,
            scale: 2,
            signed: false,
            thousandsSeparator: '.',
            radix: ',',
            lazy: false
        });

        // Ödeme butonuna tıklandığında başarılı ise
        payBtn.addEventListener("click", function () {
            Swal.fire({
                title: 'Ödeme işleminiz başarıyla gerçekleşti.',
                toast: true,
                position: 'top-end',
                timer: 3000,
                icon: 'success',
                showConfirmButton: false,
            })
        });

        // Ödeme butonuna tıklandığında başarılı değilse
        // payBtn.addEventListener("click", function () {
        //     Swal.fire({
        //         title: 'Ödeme işlemi sırasında bir hata meydana geldi.',
        //         toast: true,
        //         position: 'top-end',
        //         timer: 3000,
        //         icon: 'error',
        //         showConfirmButton: false,
        //     })
        // });
    </script><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/components/profile/payment.blade.php ENDPATH**/ ?>