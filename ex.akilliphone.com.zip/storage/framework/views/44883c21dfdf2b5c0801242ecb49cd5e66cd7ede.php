sipariş Kimliği: <?php echo e($order['orderId']); ?> / <?php echo e($order['orderNo']); ?>

<?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/emails/new-order.blade.php ENDPATH**/ ?>