<a href="#" class="big-product-card">
    <div class="card-category">
        <img width="232" height="147" src="assets/images/product-category1.png" alt="">
    </div>
    <div class="card-details">
        <div class="product-image">
            <img width="82" height="82" src="assets/images/product-thumb1.png" alt="">
        </div>
        <div class="product-info">
            <div class="product-name">Diji Mavic Pro Drone Kamera Koruyucu</div>
            <div class="product-prices">
                <div class="current">
                    <span class="price">42.42TL</span>
                    <span class="discount">%50</span>
                </div>
                <div class="old">85.56TL</div>
            </div>
        </div>
    </div>
</a>
<?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/components/product/category-item.blade.php ENDPATH**/ ?>