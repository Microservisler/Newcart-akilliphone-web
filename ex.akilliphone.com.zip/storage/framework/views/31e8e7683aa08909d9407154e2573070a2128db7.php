<?php $__env->startSection('head'); ?>
    <title>Sepetim - AkıllıPhone</title>
    <link rel="stylesheet" href="<?php echo e(url('assets/css/basket/shopping-section.css')); ?>">
    <style>
        .decrease-increase{
            text-align: center;
            border: none;
            margin: 0px;
            width: 40px;
            height: 100%;
            background: #F9F9F9;
        }
        .basket-messages {
            font-size: 12px;
            clear: both;
            width: 100%;
            margin-bottom: 15px;
            padding-right: 22px;
        }
        .basket-message {
            display: block;
            font-size: 14px;
            font-weight: 600;
            color: #313131;
        }
        .basket-message.text-danger {
            font-size:8px;
            text-align: -webkit-right;
            color: #e91e63;
        }
        .basket-message.text-success {
            font-size: 10px;
            text-align: end;
            color: #32a200;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="shopping_section">
        <div class="container" id="basket-table">
            <?php echo $__env->make('basket.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/akilliphone/subdomains/ex.akilliphone.com/resources/views/basket/index.blade.php ENDPATH**/ ?>