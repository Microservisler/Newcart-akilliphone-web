<?php $__env->startSection('head'); ?>
    <title>Ödeme Sayfası - AkıllıPhone</title>
    <link rel="stylesheet" href="<?php echo e(url('assets/css/shopping-section4.css')); ?>">
    <style>
        .pay3d-errors{
            color: #e91e63;
            border: 1px solid;
            padding: 10px;
            margin-bottom: 30px;
            border-radius: 5px;

        }
    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="shopping_section">
        <div class="container">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.payment.steps','data' => ['step' => 4]]); ?>
<?php $component->withName('payment.steps'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['step' => 4]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php if($error): ?>
                    <div class="pay3d-errors">
                        <?php echo e($error); ?>

                    </div>

                <?php else: ?>
                    <div class="signup-title">
                        <h1>Sipariş Özeti</h1>
                        Alışverişiniz için teşekkür ederiz. Siparişiniz en kısa sürede hazırlanacak.
                    </div>
                    <div class="shopping-wrapper">
                    <div class="form-wrapper">
                        <div class="order-summary">
                            <div class="order-description">
                                Sn. <strong><?php echo e($order['shippingAddress']['firstName']); ?> <?php echo e($order['shippingAddress']['lastName']); ?></strong>, <strong><?php echo e(HumanDate($order['createdAt'])); ?></strong> tarihinde yapmış olduğunuz
                                <strong><?php echo e($order['orderTotal']); ?> TL</strong> tutarındaki siparişiniz tarafımıza ulaşmıştır. Alışverişinizin özetini içeren bir mesaj ayrıca <strong>loremipsum@dolor.com</strong> adresine gönderilmiştir.
                            </div>
                        </div>
                        <div class="order-summary">
                            <div class="summary-title"> Sipariş numarası: <span class="order-number"><?php echo e($order['orderId']); ?></span></div>
                            <div>
                                Sipariş numaranızı kaybetmeyiniz. Kargo takibi ve olası işlemlerinizde bu numara üzerinden işlem yapılacaktır.
                            </div>
                        </div>
                        <div class="order-summary">
                            <div class="summary-title">Sipariş Özetiniz</div>
                            <div class="info-title">Sipariş numarası: <span class="info-descr"><?php echo e($order['orderId']); ?></span></div>
                            <div class="info-title">Alıcı: <span class="info-descr"><?php echo e($order['shippingAddress']['firstName']); ?> <?php echo e($order['shippingAddress']['lastName']); ?></span></div>
                            <div class="info-title">Teslimat Adresi: <span class="info-descr"><?php echo e($order['shippingAddress']['addressLine1']); ?> <?php echo e($order['shippingAddress']['district']); ?>/<?php echo e($order['shippingAddress']['city']); ?></span></div>
                            <div class="info-title">Ödeme Tipi: <span class="info-descr"><?php echo e($order['paymentType']['name']); ?></span></div>
                            <div class="info-title">Telefon: <span class="info-descr"><?php echo e($order['shippingAddress']['phone']); ?></span></div>
                            <div class="info-title">Tarih: <span class="info-descr"><?php echo e(HumanDate($order['createdAt'])); ?></span></div>
                        </div>
                    </div>
                    <div class="cart-wrapper">
                        <div class="header">
                            <div class="title">Siparişim</div>
                            <span class="item-count"><?php echo e(count($order['orderProducts'])); ?></span>
                        </div>
                        <div class="body">
                            <?php $__currentLoopData = $order['orderProducts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="purchased">
                                    <img src="assets/images/80x80-1.png" alt="">
                                    <div class="info">
                                        <div class="name"><?php echo e($orderProduct['name']); ?> Barkodu: <?php echo e($orderProduct['barcode']); ?> (<?php echo e($orderProduct['quantity']); ?> Adet)</div>
                                        <div class="price"><?php echo e($orderProduct['total']); ?><span>&nbsp;TL</span></div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="total">
                            <?php $__currentLoopData = $order['orderTotals']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderTotal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="info-total">
                                    <div class="descr"><?php echo e($orderTotal['name']); ?></div>
                                    <div class="price"><?php echo e($orderTotal['value']); ?><span>&nbsp;TL</span></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    </div>
        </div>
                <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/akilliphone/subdomains/ex.akilliphone.com/resources/views/payment/thankyou.blade.php ENDPATH**/ ?>