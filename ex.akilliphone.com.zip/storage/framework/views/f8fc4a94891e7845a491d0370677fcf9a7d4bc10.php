
<?php $__env->startSection('head'); ?>
    <title>Yorumlarım - AkıllıPhone</title>
    <link rel="stylesheet" href="<?php echo e(url('assets/css/profile/comments/main.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.profile.comments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="../assets/js/profile/order/profile-order.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/profile/comments/comments.blade.php ENDPATH**/ ?>