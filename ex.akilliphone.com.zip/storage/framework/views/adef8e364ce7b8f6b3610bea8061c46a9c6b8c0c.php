<section class="section-8 section-padding">
    <div class="container">
        <div class="section-title section-padding"><?php echo e($title); ?><a class="link" href="<?php echo $slug; ?>">Tümünü Gör</a>
        </div>
        <div class="product-slider owl-carousel owl-theme">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
                <?php if (isset($component)) { $__componentOriginal5ef3a6e9f6ca3594183882eb43fa756b943550ad = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Product\HomeItem2::class, ['item' => $item]); ?>
<?php $component->withName('product.home-item2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ef3a6e9f6ca3594183882eb43fa756b943550ad)): ?>
<?php $component = $__componentOriginal5ef3a6e9f6ca3594183882eb43fa756b943550ad; ?>
<?php unset($__componentOriginal5ef3a6e9f6ca3594183882eb43fa756b943550ad); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>
<?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/components/section/carousel2.blade.php ENDPATH**/ ?>