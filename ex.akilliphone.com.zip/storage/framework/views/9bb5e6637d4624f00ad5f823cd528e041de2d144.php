<section class="banner-area section-padding">
    <div class="container">
        <a href="#">
            <img class="lazyload fluid-img" data-src="<?php echo e(url('assets/images/banners/desktop-banner1.png')); ?>"
                 data-srcset="<?php echo e(url('assets/images/banners/desktop-banner1.png')); ?> 800w, <?php echo e(url('assets/images/banners/mobile-banner1.png')); ?> 320w"
                 sizes="(min-width: 768px) 400px,160px" width="1110" height="120" alt="Banner">
        </a>
    </div>
</section>
<?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/components/section/image.blade.php ENDPATH**/ ?>