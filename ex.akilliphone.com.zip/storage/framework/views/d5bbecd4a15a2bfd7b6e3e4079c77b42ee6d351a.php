
<?php $__env->startSection('head'); ?>
    <title>Favorilerim - AkıllıPhone</title>
    <link rel="stylesheet" href="<?php echo e(url('assets/css/profile/favorites/main.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="profile section-padding mx-24">
        <div class="container">
            <div class="section-title">Hesabım</div>
            <div class="profile-layout">
                <div class="left">
                    <div class="user-info">
                        <div class="shortened"><?php echo session('userNameIcon'); ?></div>
                        <div class="fullname"><?php echo session('userName'); ?></div>
                    </div>
                    <div>
                        <a href="order" class="left-section ">
                            <div class="left-section-title">
                                <img src="../assets/images/icons/order.svg" alt="">
                                Siparişlerim
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="coupons" class="left-section" >
                            <div class="left-section-title">
                                <img src="../assets/images/icons/coupon.svg" alt="">
                                Kuponlarım
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="favorites" class="left-section" active>
                            <div class="left-section-title">
                                <img src="../assets/images/icons/favorite.svg" alt="">
                                Favorilerim / Listelerim
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="comments" class="left-section ">
                            <div class="left-section-title">
                                <img src="../assets/images/icons/comment.svg" alt="">
                                Yorumlarım
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="informations" class="left-section">
                            <div class="left-section-title">
                                <img src="../assets/images/icons/info.svg" alt="">
                                Üyelik Bilgilerim
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="address" class="left-section">
                            <div class="left-section-title">
                                <img src="../assets/images/icons/address.svg" alt="">
                                Adres Bilgilerim
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847" viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527" d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z" transform="translate(11.054 10.947) rotate(180)" opacity="0.492"/>
                            </svg>
                        </a>
                        <a href="payment"  class="left-section">
                            <div class="left-section-title">
                                <img src="../assets/images/icons/card.svg" alt="">
                                Harici Ödeme
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847"
                                 viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527"
                                      d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z"
                                      transform="translate(11.054 10.947) rotate(180)" opacity="0.492" />
                            </svg>
                        </a>
                    </div>
                </div>
                <div class="right">
                    <div class="profile-infos">
                        <div class="top">
                            <div class="title">Favorilerim</div>
                            <div>3 ürün</div>
                        </div>
                        <div class="favorite-list">
                            <div class="row">
                                <a href="#" class="favorite-item">
                                    <div>
                                        <div class="product-image">
                                            <img class="lazyload" width="140" height="140" data-src="../assets/images/product-images/11.png" alt="product image" src="assets/images/product-images/11.png">
                                        </div>
                                        <div class="product-info">
                                            <div class="product-name">
                                                Baseus SIMU S1 ANC TWS Bluetooth 5.1 Kulaklık DSP
                                            </div>
                                            <div class="product-price">
                                                42.42TL
                                            </div>
                                            <div class="product-old-price">
                                                85,56TL
                                            </div>
                                        </div>
                                        <button class="delete-favorite">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24"><path fill="#fff" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                                        </button>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="../assets/js/profile/order/profile-order.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/components/profile/favorites.blade.php ENDPATH**/ ?>