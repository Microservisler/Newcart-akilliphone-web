<?php $__env->startSection('head'); ?>
    <title>Ödeme Sayfası - AkıllıPhone</title>
    <link rel="stylesheet" href="<?php echo e(url('assets/css/shopping-section3.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.payment.steps','data' => ['step' => 4]]); ?>
<?php $component->withName('payment.steps'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['step' => 4]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <div class="signup-title">
            <h1>Sipariş Özeti</h1>
            Alışverişiniz için teşekkür ederiz. Siparişiniz en kısa sürede hazırlanacak.
        </div>

        <div class="shopping-wrapper">
            <div class="form-wrapper">
                <div class="order-summary">
                    <div class="order-description">
                        Sn. <strong><?php echo e($order['shippingAddress']['name']); ?></strong>, <strong><?php echo e($order['createdAt']); ?></strong> tarihinde yapmış olduğunuz
                        <strong><?php echo e($order['orderTotal']); ?> TL</strong> tutarındaki siparişiniz tarafımıza ulaşmıştır. Alışverişinizin özetini içeren bir mesaj ayrıca <strong>loremipsum@dolor.com</strong> adresine gönderilmiştir.
                    </div>
                </div>
                <div class="order-summary">
                    <div class="summary-title"> Sipariş numarası: <span class="order-number"><?php echo e($order['orderNo']); ?></span></div>
                    <div>
                        Sipariş numaranızı kaybetmeyiniz. Kargo takibi ve olası işlemlerinizde bu numara üzerinden işlem yapılacaktır.
                    </div>
                </div>
                <div class="order-summary">
                    <div class="summary-title">Sipariş Özetiniz</div>
                    <div class="info-title">Sipariş numarası: <span class="info-descr"><?php echo e($order['orderNo']); ?></span></div>
                    <div class="info-title">Alıcı: <span class="info-descr"><?php echo e($order['shippingAddress']['name']); ?></span></div>
                    <div class="info-title">Teslimat Adresi: <span class="info-descr"><?php echo e($order['shippingAddress']['addressLine1']); ?><br><?php echo e($order['shippingAddress']['district']); ?>/<?php echo e($order['shippingAddress']['city']); ?></span></div>
                    <div class="info-title">Ödeme Tipi: <span class="info-descr"><?php echo e($order['paymentType']['name']); ?></span></div>
                    <div class="info-title">Telefon: <span class="info-descr"><?php echo e($order['customer']['telefon']); ?></span></div>
                    <div class="info-title">Tarih: <span class="info-descr"><?php echo e($order['createdAt']); ?></span></div>
                </div>

            </div>
            <div class="cart-wrapper">
                <div class="header">
                    <div class="title">Siparişim</div>
                    <span class="item-count">2</span>
                </div>
                <div class="body">
                    <div class="purchased">
                        <img src="assets/images/80x80-1.png" alt="">
                        <div class="info">
                            <div class="name">ALLY Magnetic Air Vent
                                Mıknatıslı Araç TutucuKablo Klipsli-SİYAH</div>
                            <div class="price">999,90<span>&nbsp;TL</span></div>
                        </div>
                    </div>
                    <div class="purchased">
                        <img src="assets/images/80x80-2.png" alt="">
                        <div class="info">
                            <div class="name">Xiaomi Mi Band 5 Metal
                                Kayış Kordon Kopçalı Milano Loop-SİYAH</div>
                            <div class="price">2.499,00<span>&nbsp;TL</span></div>
                        </div>
                    </div>
                </div>
                <div class="total">
                    <div class="info-total">
                        <div class="descr">Ürünler Toplamı (KDV Dahil)</div>
                        <div class="price">169.80<span>&nbsp;TL</span></div>
                    </div>
                    <div class="info-total">
                        <div class="descr">Kargo</div>
                        <div class="price">Ücretsiz</div>
                    </div>
                </div>
            </div>
        </div>
    </div><?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="../assets/js/profile/order/profile-order.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/payment/step-4.blade.php ENDPATH**/ ?>