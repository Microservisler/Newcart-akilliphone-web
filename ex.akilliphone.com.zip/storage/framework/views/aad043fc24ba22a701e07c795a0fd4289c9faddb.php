
<?php $__env->startSection('head'); ?>
    <title>Kuponlarım - AkıllıPhone</title>
    <link rel="stylesheet" href="<?php echo e(url('assets/css/profile/coupons/main.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <section class="profile section-padding mx-24">
        <div class="container">
            <div class="section-title">Hesabım</div>
            <div class="profile-layout">
                <div class="left">
                    <div class="user-info">
                        <div class="shortened">EK</div>
                        <div class="fullname">Emre Karataş</div>
                    </div>
                    <div>
                        <a href="../siparisler" class="left-section">
                            <div class="left-section-title">
                                <img src="assets/images/icons/order.svg" alt="">
                                Siparişlerim
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847"
                                 viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527"
                                      d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z"
                                      transform="translate(11.054 10.947) rotate(180)" opacity="0.492" />
                            </svg>
                        </a>
                        <a href="../kuponlarim" class="left-section active">
                            <div class="left-section-title">
                                <img src="assets/images/icons/coupon.svg" alt="">
                                Kuponlarım
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847"
                                 viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527"
                                      d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z"
                                      transform="translate(11.054 10.947) rotate(180)" opacity="0.492" />
                            </svg>
                        </a>
                        <a href="../favorilerim" class="left-section">
                            <div class="left-section-title">
                                <img src="assets/images/icons/favorite.svg" alt="">
                                Favorilerim / Listelerim
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847"
                                 viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527"
                                      d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z"
                                      transform="translate(11.054 10.947) rotate(180)" opacity="0.492" />
                            </svg>
                        </a>
                        <a href="../yorumlarim" class="left-section">
                            <div class="left-section-title">
                                <img src="assets/images/icons/comment.svg" alt="">
                                Yorumlarım
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847"
                                 viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527"
                                      d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z"
                                      transform="translate(11.054 10.947) rotate(180)" opacity="0.492" />
                            </svg>
                        </a>
                        <a href="../bilgilerim" class="left-section">
                            <div class="left-section-title">
                                <img src="assets/images/icons/info.svg" alt="">
                                Üyelik Bilgilerim
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847"
                                 viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527"
                                      d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z"
                                      transform="translate(11.054 10.947) rotate(180)" opacity="0.492" />
                            </svg>
                        </a>
                        <a href="../address/index.html" class="left-section">
                            <div class="left-section-title">
                                <img src="assets/images/icons/address.svg" alt="">
                                Adres Bilgilerim
                            </div>
                            <svg xmlns="http://www.w3.org/2000/svg" width="5.214" height="8.847"
                                 viewBox="0 0 5.214 8.847">
                                <path id="Path_12527" data-name="Path 12527"
                                      d="M11.054,2.891l-.8-.791L5.84,6.523l4.423,4.423.791-.791L7.422,6.523Z"
                                      transform="translate(11.054 10.947) rotate(180)" opacity="0.492" />
                            </svg>
                        </a>
                    </div>
                </div>
                <div class="right">
                    <div class="profile-infos">
                        <div class="top">
                            <div class="title">Kuponlarım</div>
                            <div>3 kupon</div>
                        </div>
                        <div class="coupon-list">
                            <div class="coupon">
                                <div class="coupon-header">
                                    <div class="limit">
                                        <div class="limit-top">20<span>TL indirim</span></div>
                                        <div class="limit-bottom">Alt limit: 300 TL</div>
                                    </div>
                                    <div>
                                        <a href="#" class="direct-btn">Ürünlere git</a>
                                        <button id="open-details" class="details-btn">Detaylar</button>
                                    </div>
                                </div>
                                <div class="coupon-body">
                                    <div class="product-links">
                                        <a href="#" class="product">
                                            <img height="48" width="48" src="./assets/images/product1.png" alt="">
                                        </a>
                                        <a href="#" class="product">
                                            <img height="48" width="48" src="./assets/images/product2.png" alt="">
                                        </a>
                                        <a href="#" class="product">
                                            <img height="48" width="48" src="./assets/images/product3.png" alt="">
                                        </a>
                                        <a href="#" class="product">
                                            <img height="48" width="48" src="./assets/images/product4.png" alt="">
                                        </a>
                                        <a href="#" class="product">
                                            <img height="48" width="48" src="./assets/images/product5.png" alt="">
                                        </a>
                                    </div>
                                </div>
                                <div class="coupon-footer">
                                    <div class="coupon-footer-top">
                                        <div class="left-circle"></div>
                                        <div class="mid-line"></div>
                                        <div class="right-circle"></div>
                                    </div>
                                    <div class="coupon-footer-bottom">
                                        <div>
                                            <a href="#">Aksesuarlar</a> kategorisinde geçerlidir.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="site-menu" id="site-menu">
                        <div class="site-menu-title">
                            Detaylar
                            <div class="discount-title">300 TL üzerine 20TL indirim.</div>
                        </div>
                        <div class="site-menu-details">
                            <div class="details-title">Kullanım şartları</div>
                            <ol>
                                <li>Minimum 150 TL ve üzeri alışverişlerde geçerlidir.</li>
                                <li>31.03.2023 23:59 tarihine kadar geçerlidir.</li>
                                <li>İlk 33 kullanımda geçerlidir.</li>
                                <li>Aksesuarlar kategorisi ürünlerinde geçerlidir.</li>
                            </ol>
                            <div class="basket-warning">
                                Kuponunu sepette kullanabilirsin
                            </div>
                        </div>

                    </div>
                    <div id="close-canvas" class="close-canvas"></div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="./assets/js/profile/coupons/signup-select.js"></script>
    <script src="./assets/js/profile/coupons/flatpickr.min.js"></script>
    <script src="./assets/js/profile/coupons/mask.min.js"></script>
    <script>
        let siteMenu = document.getElementById('site-menu');
        let openBtn = document.getElementById('open-details');
        let closeCanvas = document.getElementById('close-canvas');
        openBtn.addEventListener("click", function(){
            if (siteMenu.classList.contains('site-menu')) {
                siteMenu.classList.add('site-menu--active')
                closeCanvas.style.display = "block"
                document.body.style.overflow = 'hidden'
            }
        })
        closeCanvas.addEventListener("click", function(){
            if (siteMenu.classList.contains('site-menu--active')) {
                siteMenu.classList.remove('site-menu--active')
                closeCanvas.style.display = "none"
                document.body.style.overflow = 'auto'
            }
        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/profile/coupons/coupons.blade.php ENDPATH**/ ?>