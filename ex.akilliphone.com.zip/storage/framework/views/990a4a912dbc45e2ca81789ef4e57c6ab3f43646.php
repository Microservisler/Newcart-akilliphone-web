<?php $__env->startSection('head'); ?>
    <title>Akilliphone - Online Store</title>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if($main_slider && isset($main_slider['data'])): ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.section.main-slider','data' => ['items' => $main_slider['data']['items']]]); ?>
<?php $component->withName('section.main-slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($main_slider['data']['items'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalfa14ef00c5c7422154d62f4608701d3c705f9f03 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Section\Image::class, []); ?>
<?php $component->withName('section.image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfa14ef00c5c7422154d62f4608701d3c705f9f03)): ?>
<?php $component = $__componentOriginalfa14ef00c5c7422154d62f4608701d3c705f9f03; ?>
<?php unset($__componentOriginalfa14ef00c5c7422154d62f4608701d3c705f9f03); ?>
<?php endif; ?>
    <?php if($product_slider && isset($product_slider['data'])): ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.section.product-slider','data' => ['items' => $product_slider['data']['items']]]); ?>
<?php $component->withName('section.product-slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product_slider['data']['items'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php else: ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.section.lost','data' => ['title' => 'İmage section']]); ?>
<?php $component->withName('section.lost'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('İmage section')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.asyn.carousel','data' => ['sectionId' => 'section1','title' => 'Aksesuarlar','slug' => '/reyonlar/arac-aksesuarlari-280?category=2']]); ?>
<?php $component->withName('asyn.carousel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['sectionId' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('section1'),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Aksesuarlar'),'slug' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('/reyonlar/arac-aksesuarlari-280?category=2')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.asyn.carousel','data' => ['sectionId' => 'section2','title' => 'Araç Aksesuarları','slug' => '#slug']]); ?>
<?php $component->withName('asyn.carousel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['sectionId' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('section2'),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Araç Aksesuarları'),'slug' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('#slug')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.asyn.carousel','data' => ['sectionId' => 'section3','title' => 'Ev Yaşam','slug' => '/reyonlar/hava-nemlendiriciler-340?category=83']]); ?>
<?php $component->withName('asyn.carousel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['sectionId' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('section3'),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Ev Yaşam'),'slug' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('/reyonlar/hava-nemlendiriciler-340?category=83')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.asyn.carousel','data' => ['sectionId' => 'section4','title' => 'Şarj Aletleri','slug' => '#slug']]); ?>
<?php $component->withName('asyn.carousel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['sectionId' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('section4'),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Şarj Aletleri'),'slug' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('#slug')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.asyn.carousel','data' => ['sectionId' => 'section5','title' => 'Dönüştürücüler','slug' => '#slug']]); ?>
<?php $component->withName('asyn.carousel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['sectionId' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('section5'),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Dönüştürücüler'),'slug' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('#slug')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.asyn.carousel','data' => ['sectionId' => 'section6','title' => 'Ses Sistemleri','slug' => '#slug']]); ?>
<?php $component->withName('asyn.carousel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['sectionId' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('section6'),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Ses Sistemleri'),'slug' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('#slug')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.asyn.carousel','data' => ['sectionId' => 'section7','title' => 'Kişisel Ürünler','slug' => '#slug']]); ?>
<?php $component->withName('asyn.carousel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['sectionId' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('section7'),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Kişisel Ürünler'),'slug' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('#slug')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
    <script>
        const { createApp } = Vue;
        var app = createApp({
            data() {
                return {
                    sections: {},
                    error:"",
                    cdnUrl:cdnUrl,
                    target:'',
                }
            },
            created: function(){

            },
            updated: function () {
                this.$nextTick(function () {
                    create_product_owl_slider( '#' + this.target +' .product-asyn-slider');
                })
            },
            methods : {
                getProductImageUrl: function(url, w, h){
                    return webService.getProductImageUrl(url, w, h);
                }
            }
        }).mount('#app-basic');
        webService.getSectionProducts('products?cat=1,2,3,6,5,12,9,10,8,7,4,11,48,55,63,57,44,45,47,46,13,21,16,20,19,23,24,30,31,27,32,28,25,29,26,34,41,40,36,38,37,39,35,33,43&sort=newly&orderby=desc&offset=12', 'section1');
        webService.getSectionProducts('products?cat=2,3,6,5,12,9,10,8,7,4,11&sort=newly&orderby=desc&offset=12', 'section2');
        webService.getSectionProducts('products?cat=78,83,85,87,80,88,84,81,86,79&sort=newly&orderby=desc&offset=12', 'section3');
        webService.getSectionProducts('products?cat=103,105,107,110,104,108,109,111,106&sort=newly&orderby=desc&offset=12', 'section4');
        webService.getSectionProducts('products??cat=89,95,92,102,101,90,96,98,100,94,97,91,99,93&sort=newly&orderby=desc&offset=12', 'section5');
        webService.getSectionProducts('products?cat=112,113,115,119,117,122,118,114,121,116,120&sort=newly&orderby=desc&offset=12', 'section6');
        webService.getSectionProducts('products?cat=84&sort=newly&orderby=desc&offset=12', 'section7');
        lazyload();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/home/test.blade.php ENDPATH**/ ?>