<section class="four-product-slider section-padding mx-24">
    <div class="container">
        <div class="four-slider owl-carousel owl-theme">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(url('reyonlar')); ?>/<?php echo e($row['slug']); ?>" class="big-product-card">
                    <?php $__currentLoopData = $row['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card-category">
                        <img width="232" height="147" src="<?php echo getProductImageUrl($item['brandImage'], 232, 147); ?>" alt="">
                    </div>
                    <div class="card-details">
                        <div class="product-image">
                            <img width="82" height="82" src="<?php echo getProductImageUrl($item['image'], 82, 82); ?>" alt="">
                        </div>
                        <div class="product-info">
                            <div class="product-name"><?php echo e($item['name']); ?></div>
                            <div class="product-prices">
                                <div class="current">
                                    <span class="price">42.42TL</span>
                                    <span class="discount">%50</span>
                                </div>
                                <div class="old">85.56TL</div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH /home/akilliphone/subdomains/ethem.akilliphone.com/resources/views/components/section/category.blade.php ENDPATH**/ ?>